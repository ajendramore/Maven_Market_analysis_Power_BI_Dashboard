1. Find and Open "Dynamic Location.txt" file from same folder.
2. Remove all text from "Dynamic Location.txt" file and paste current file location that ends with "...\Maven Market PBI Dashboard" then save and close it
3. Find and open "Mevan Market.pbi" file and go to Transform Data (Query editor)
4. Find folder "Dynamic Location" in Queries Tab, click on "Location" Query, and edit Source from applied step pane and locate "Dynamic Location.txt." file on your system and click ok
5. Check all queries in folder "Fact and Dim Tables"
6. Save & Close.

Explore Dashboard!!

For any queries kindly reachout to me on,

Linked in > https://www.linkedin.com/in/ajendramore/
Mail me at ajendramore@gmail.com