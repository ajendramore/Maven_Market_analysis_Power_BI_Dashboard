Desc

the maven market dashboard is visually engaging Power Bi dashboard that help user to explore various segment and insights for consumer as well as product sales with over 8 lakhs order in total and over 10,000 customers


readme

mevan_market_Dashboard

the mevan market dashboard is visually engaging Power BI dashboard that help user to explore various segment and  insights for consumer as well as sales representative with over 8 lakhs order in total and over 10,000 customers

Power Query - EDA from various excel sheets transform them by cleaning, formatting.

Complex DAX - 

Power BI - create dashboard to navigate pages, slicer to filter segment and year scroll bar and bottom to navigate top bottom of sales representative, customer and country.

preview of Sale Representative & Customer ![Dashboard](https://github.com/ajendramore/ajendramore-global_superstore_Dashboard/blob/main/global_superstore_2016_Dashboard_Representative.png)

preview of Country ![Dashboard](https://github.com/ajendramore/ajendramore-global_superstore_Dashboard/blob/main/global_superstore_2016_Dashboard_Country.png)